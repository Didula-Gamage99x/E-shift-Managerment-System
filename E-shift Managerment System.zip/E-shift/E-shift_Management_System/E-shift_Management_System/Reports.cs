﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class Reports : Form
    {
        public Reports()
        {
            InitializeComponent();// Initialize UI components
            dgvReports.Columns.Clear();
            dgvReports.Columns.Add("JobID", "Job ID");
            dgvReports.Columns.Add("Customer", "Customer");
            dgvReports.Columns.Add("StartLocation", "Start");
            dgvReports.Columns.Add("EndLocation", "End");
            
            dgvReports.Columns.Add("VehicleType", "Vehicle Type");
            dgvReports.Columns.Add("ItemReference", "Item Reference");
            dgvReports.Columns.Add("Weight", "Weight (kg)");
            dgvReports.Columns.Add("Date", "Date");
            dgvReports.Columns.Add("Status", "Status");

            cmbFilteritem.Items.AddRange(new string[] { "All", "Pending", "Accepted", "Declined" });
            cmbFilteritem.SelectedIndex = 0;

        

            LoadJobs(); // Load all jobs by default
        }
        private void LoadJobs(string statusFilter = "All")
        {
            dgvReports.Rows.Clear();
            int totalJobs = 0;
            decimal totalAcceptedWeight = 0;

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"SELECT j.job_id, j.customer, j.start_location, j.end_location, 
                               j.job_date, j.status, j.weight, j.vehicle_type, i.name as item_reference
                               FROM jobs j
                               LEFT JOIN items i ON j.item_id = i.id";

                if (statusFilter != "All")
                {
                    query += " WHERE j.status = @status";
                }

                SqlCommand cmd = new SqlCommand(query, conn);

                if (statusFilter != "All")
                {
                    cmd.Parameters.AddWithValue("@status", statusFilter);
                }

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    totalJobs++;
                    string status = reader["status"].ToString();
                    decimal weight = reader["weight"] != DBNull.Value ?
                                   Convert.ToDecimal(reader["weight"]) : 0;

                    if (status == "Accepted")
                    {
                        totalAcceptedWeight += weight;
                    }

                    dgvReports.Rows.Add(
                        reader["job_id"].ToString(),
                        reader["customer"].ToString(),
                        reader["start_location"].ToString(),
                        reader["end_location"].ToString(),
                        reader["vehicle_type"] != DBNull.Value ? reader["vehicle_type"].ToString() : "",
                        reader["item_reference"] != DBNull.Value ? reader["item_reference"].ToString() : "",
                        weight.ToString("0.00"),
                        Convert.ToDateTime(reader["job_date"]).ToString("yyyy-MM-dd"),
                        status
                    );
                }
            }

            // Display totals in existing controls 
            lblTjobs.Text = $"Total Jobs : {totalJobs}";
            lblTweight.Text = $"Total Weight : {totalAcceptedWeight.ToString("0.00")} kg";
        }

        private void Reports_Load(object sender, EventArgs e)
        {

        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
          
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvReports_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbFilteritem_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedStatus = cmbFilteritem.SelectedItem.ToString();
            LoadJobs(selectedStatus);
        }
    }
}
