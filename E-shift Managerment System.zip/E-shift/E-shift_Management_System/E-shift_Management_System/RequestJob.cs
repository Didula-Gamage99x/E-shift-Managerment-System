﻿using E_shift_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace E_shift_Management_System
{
    public partial class RequestJob : Form
    {
        private string currentCustomer;// Stores the username of the logged-in customer
        public RequestJob(string username)
        {
            InitializeComponent();// Initialize UI components
            currentCustomer = username;// Store the current customer

            InitializeItemDropdown();// Load items from database
            InitializeVehicleDropdown();// Load vehicle types
            AttachCalculationEvents(); // Set up price calculation triggers
        }
        private void InitializeItemDropdown()
        {
            cmbItems.Items.Clear();// Clear existing items
            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    // Query to get all available items
                    string query = "SELECT id, name FROM items ORDER BY name";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Add each item to the dropdown
                            cmbItems.Items.Add(new Item(
                                Convert.ToInt32(reader["id"]),
                                reader["name"].ToString()
                            ));
                        }
                    }
                }
                // Configure how items are displayed in the dropdown
                cmbItems.DisplayMember = "Name";
                cmbItems.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading items: {ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeVehicleDropdown()
        {
            cmbVehicleType.Items.Clear();
            // Add standard vehicle options
            cmbVehicleType.Items.AddRange(new string[] {
                "Small Lorry",
                "Medium Lorry",
                "Large Lorry",
                "Van"
            });
        }
        private void AttachCalculationEvents()
        {
            numWeight.ValueChanged += (s, e) => UpdateEstimatedPrice();
            cmbVehicleType.SelectedIndexChanged += (s, e) => UpdateEstimatedPrice();
        }

        private void UpdateEstimatedPrice()
        {
            // Return early if required fields are missing
            if (cmbVehicleType.SelectedItem == null || numWeight.Value <= 0)
            {
                lblEstimatedPrice.Text = "Estimated Price: Rs. 0.00";
                return;
            }
            // Calculate and display price
            decimal weight = numWeight.Value;
            string vehicleType = cmbVehicleType.SelectedItem.ToString();
            decimal price = CalculatePrice(weight, vehicleType);

            lblEstimatedPrice.Text = $"Estimated Price: Rs. {price.ToString("N2")}";
        }
        private decimal CalculatePrice(decimal weight, string vehicleType)
        {
            // Round up to nearest 5kg increment
            decimal roundedWeight = Math.Ceiling(weight / 5) * 5;

            // Pricing structure
            switch (vehicleType)
            {
                case "Small Lorry": return 1000 + (roundedWeight * 10);
                case "Medium Lorry": return 1500 + (roundedWeight * 8);
                case "Large Lorry": return 2000 + (roundedWeight * 6);
                default: return 800 + (roundedWeight * 12);
            }
        }


        public class Item
        {
            public int Id { get; set; } // Database item ID
            public string Name { get; set; } // Display name

            public Item(int id, string name)
            {
                Id = id;
                Name = name;
            }

            // Display just the name in dropdown
            public override string ToString()
            {
                return Name;
            }
        }


        private string GenerateJobID()
        {
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                // Get current job count to generate next ID
                string countQuery = "SELECT COUNT(*) FROM jobs";
                return "J" + ((int)new SqlCommand(countQuery, conn).ExecuteScalar() + 1).ToString("D3");
            }
        }


        private void RequestJob_Load(object sender, EventArgs e)
        {
            // Initialize price display
            lblEstimatedPrice.Text = "Estimated Price: Rs. 0.00";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            {
                // Get all form values
                string start = txtStartlo.Text.Trim();
                string end = txtEndlo.Text.Trim();
                DateTime date = dtpDate.Value;
                decimal weight = numWeight.Value;
                string vehicle = cmbVehicleType.SelectedItem?.ToString();
                Item selectedItem = cmbItems.SelectedItem as Item;

                // Validate required fields
                if (string.IsNullOrEmpty(start) || string.IsNullOrEmpty(end) ||
                    selectedItem == null || weight <= 0 || string.IsNullOrEmpty(vehicle))
                {
                    MessageBox.Show("Please fill all fields");
                    return;
                }

                try
                {
                    using (SqlConnection conn = DatabaseHelper.GetConnection())
                    {
                        conn.Open();
                        string query = @"INSERT INTO jobs 
                      (job_id, customer, start_location, end_location, 
                       job_date, status, item_id, weight, vehicle_type)
                      VALUES 
                      (@id, @customer, @start, @end, @date, @status, @itemId, @weight, @vehicle)";

                        SqlCommand cmd = new SqlCommand(query, conn);
                        // Add parameters to prevent SQL injection
                        cmd.Parameters.AddWithValue("@id", GenerateJobID());
                        cmd.Parameters.AddWithValue("@customer", currentCustomer);
                        cmd.Parameters.AddWithValue("@start", start);
                        cmd.Parameters.AddWithValue("@end", end);
                        cmd.Parameters.AddWithValue("@date", date);
                        cmd.Parameters.AddWithValue("@status", "Pending");
                        cmd.Parameters.AddWithValue("@itemId", selectedItem.Id);
                        cmd.Parameters.AddWithValue("@weight", weight);
                        cmd.Parameters.AddWithValue("@vehicle", vehicle);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            MessageBox.Show("Job created successfully!");
                            this.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error creating job: {ex.Message}");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
