﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class ManageItems : Form
    {
        public ManageItems()
        {
            InitializeComponent();// Initialize UI components
            dgvMItems.Columns.Clear();
            dgvMItems.Columns.Add("ID", "ID");
            dgvMItems.Columns.Add("Name", "Item Name");
            Loaditems(); // This makes data load automatically
        }
        private void Loaditems()
        {
            dgvMItems.Rows.Clear();

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM items";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    string name = reader["name"].ToString();

                    dgvMItems.Rows.Add(id, name);
                }
            }
        }
        private void ManageProducts_Load(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvMItems.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a Item to delete.");
                return;
            }
            // Get ID of selected item
            int id = Convert.ToInt32(dgvMItems.SelectedRows[0].Cells[0].Value);

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string delete = "DELETE FROM items WHERE id = @id"; // Parameterized query
                SqlCommand cmd = new SqlCommand(delete, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Item deleted.");
            Loaditems();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close(); // Go back to Admin Dashboard
        }

        private void ManageItems_Load(object sender, EventArgs e)
        {

        }

        private void dgvMItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name = txtItemName.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Enter Item name.");
                return;
            }

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string insert = "INSERT INTO items (name) VALUES (@name)";
                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Item added.");
            txtItemName.Clear();
            Loaditems();
        }
    } 
    
}
