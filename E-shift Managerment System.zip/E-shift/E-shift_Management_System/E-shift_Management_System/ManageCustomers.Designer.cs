﻿namespace E_shift_Management_System
{
    partial class ManageCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvMcustomers = new System.Windows.Forms.DataGridView();
            this.btnAcustomer = new System.Windows.Forms.Button();
            this.btnDcustomer = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.User_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMcustomers)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvMcustomers
            // 
            this.dgvMcustomers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMcustomers.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvMcustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMcustomers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.User_Name,
            this.Password,
            this.contact});
            this.dgvMcustomers.Location = new System.Drawing.Point(34, 21);
            this.dgvMcustomers.Name = "dgvMcustomers";
            this.dgvMcustomers.Size = new System.Drawing.Size(587, 295);
            this.dgvMcustomers.TabIndex = 0;
            this.dgvMcustomers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMcustomers_CellContentClick);
            // 
            // btnAcustomer
            // 
            this.btnAcustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnAcustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAcustomer.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcustomer.Location = new System.Drawing.Point(34, 345);
            this.btnAcustomer.Name = "btnAcustomer";
            this.btnAcustomer.Size = new System.Drawing.Size(125, 39);
            this.btnAcustomer.TabIndex = 1;
            this.btnAcustomer.Text = "Add Customer";
            this.btnAcustomer.UseVisualStyleBackColor = false;
            this.btnAcustomer.Click += new System.EventHandler(this.btnAcustomer_Click);
            // 
            // btnDcustomer
            // 
            this.btnDcustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnDcustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDcustomer.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDcustomer.Location = new System.Drawing.Point(202, 345);
            this.btnDcustomer.Name = "btnDcustomer";
            this.btnDcustomer.Size = new System.Drawing.Size(125, 39);
            this.btnDcustomer.TabIndex = 1;
            this.btnDcustomer.Text = "Delete Customer";
            this.btnDcustomer.UseVisualStyleBackColor = false;
            this.btnDcustomer.Click += new System.EventHandler(this.btnDcustomer_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(575, 401);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 37);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // User_Name
            // 
            this.User_Name.HeaderText = "User Name";
            this.User_Name.Name = "User_Name";
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            // 
            // contact
            // 
            this.contact.HeaderText = "Contact Number";
            this.contact.Name = "contact";
            // 
            // ManageCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(662, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnDcustomer);
            this.Controls.Add(this.btnAcustomer);
            this.Controls.Add(this.dgvMcustomers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "ManageCustomers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManageCustomers";
            this.Load += new System.EventHandler(this.ManageCustomers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMcustomers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvMcustomers;
        private System.Windows.Forms.Button btnAcustomer;
        private System.Windows.Forms.Button btnDcustomer;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DataGridViewTextBoxColumn User_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn contact;
    }
}