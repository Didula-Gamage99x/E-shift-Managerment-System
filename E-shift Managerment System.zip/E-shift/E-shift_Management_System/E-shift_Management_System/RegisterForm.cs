﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();// Initialize UI components
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtNewUser.Text.Trim();
            string contact = txtContact.Text.Trim();
            string password = txtNewPass.Text.Trim();
            string confirmPassword = txtConfirmPassword.Text.Trim();

            // Validate all fields
            if (string.IsNullOrEmpty(username) ||
                string.IsNullOrEmpty(contact) ||
                string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Please fill in all fields.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate contact number (10 digits)
            if (contact.Length != 10 || !long.TryParse(contact, out _))
            {
                MessageBox.Show("Please enter a valid 10-digit contact number.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate password match
            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate password strength 
            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    conn.Open();

                    // Check for existing user
                    string checkQuery = "SELECT COUNT(*) FROM users WHERE username = @user OR contact = @contact";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@user", username);
                    checkCmd.Parameters.AddWithValue("@contact", contact);
                    int exists = (int)checkCmd.ExecuteScalar();

                    if (exists > 0)
                    {
                        MessageBox.Show("Username or contact number already exists.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Register new customer
                    string insertQuery = @"INSERT INTO users 
                                        (username, contact, password, role) 
                                        VALUES (@user, @contact, @pass, 'Customer')";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                    insertCmd.Parameters.AddWithValue("@user", username);
                    insertCmd.Parameters.AddWithValue("@contact", contact);
                    insertCmd.Parameters.AddWithValue("@pass", password);
                    insertCmd.ExecuteNonQuery();

                    MessageBox.Show("Registration successful! You can now log in.", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Registration Failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void txtContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numbers and backspace
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void txtContact_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void lblContact_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
