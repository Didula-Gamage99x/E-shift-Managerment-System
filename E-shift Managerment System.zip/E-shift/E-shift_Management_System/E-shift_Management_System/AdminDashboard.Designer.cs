﻿namespace E_shift_Management_System
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMcust = new System.Windows.Forms.Button();
            this.btnMjobr = new System.Windows.Forms.Button();
            this.btnVreports = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnMitems = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMcust
            // 
            this.btnMcust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnMcust.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMcust.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMcust.Location = new System.Drawing.Point(28, 127);
            this.btnMcust.Name = "btnMcust";
            this.btnMcust.Size = new System.Drawing.Size(134, 41);
            this.btnMcust.TabIndex = 0;
            this.btnMcust.Text = "Manage Customers";
            this.btnMcust.UseVisualStyleBackColor = false;
            this.btnMcust.Click += new System.EventHandler(this.btnMcust_Click);
            // 
            // btnMjobr
            // 
            this.btnMjobr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnMjobr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMjobr.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMjobr.Location = new System.Drawing.Point(209, 127);
            this.btnMjobr.Name = "btnMjobr";
            this.btnMjobr.Size = new System.Drawing.Size(149, 41);
            this.btnMjobr.TabIndex = 0;
            this.btnMjobr.Text = "Manage Job Requests";
            this.btnMjobr.UseVisualStyleBackColor = false;
            this.btnMjobr.Click += new System.EventHandler(this.btnMjobr_Click);
            // 
            // btnVreports
            // 
            this.btnVreports.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnVreports.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVreports.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVreports.Location = new System.Drawing.Point(28, 250);
            this.btnVreports.Name = "btnVreports";
            this.btnVreports.Size = new System.Drawing.Size(111, 34);
            this.btnVreports.TabIndex = 0;
            this.btnVreports.Text = "View Reports ";
            this.btnVreports.UseVisualStyleBackColor = false;
            this.btnVreports.Click += new System.EventHandler(this.btnVreports_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(461, 294);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 37);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Location = new System.Drawing.Point(235, 25);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(83, 19);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "Welcome";
            // 
            // btnMitems
            // 
            this.btnMitems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnMitems.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMitems.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMitems.Location = new System.Drawing.Point(388, 127);
            this.btnMitems.Name = "btnMitems";
            this.btnMitems.Size = new System.Drawing.Size(134, 41);
            this.btnMitems.TabIndex = 2;
            this.btnMitems.Text = "Manage Items";
            this.btnMitems.UseVisualStyleBackColor = false;
            this.btnMitems.Click += new System.EventHandler(this.btnMitems_Click);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(548, 343);
            this.Controls.Add(this.btnMitems);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnVreports);
            this.Controls.Add(this.btnMjobr);
            this.Controls.Add(this.btnMcust);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMcust;
        private System.Windows.Forms.Button btnMjobr;
        private System.Windows.Forms.Button btnVreports;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnMitems;
    }
}