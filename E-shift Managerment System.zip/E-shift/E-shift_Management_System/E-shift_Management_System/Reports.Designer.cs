﻿namespace E_shift_Management_System
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvReports = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            this.cmbFilteritem = new System.Windows.Forms.ComboBox();
            this.lblTweight = new System.Windows.Forms.Label();
            this.lblTjobs = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvReports
            // 
            this.dgvReports.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvReports.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvReports.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReports.Location = new System.Drawing.Point(42, 41);
            this.dgvReports.Name = "dgvReports";
            this.dgvReports.Size = new System.Drawing.Size(728, 150);
            this.dgvReports.TabIndex = 0;
            this.dgvReports.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReports_CellContentClick);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(713, 281);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 36);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // cmbFilteritem
            // 
            this.cmbFilteritem.FormattingEnabled = true;
            this.cmbFilteritem.Location = new System.Drawing.Point(42, 239);
            this.cmbFilteritem.Name = "cmbFilteritem";
            this.cmbFilteritem.Size = new System.Drawing.Size(147, 21);
            this.cmbFilteritem.TabIndex = 2;
            this.cmbFilteritem.SelectedIndexChanged += new System.EventHandler(this.cmbFilteritem_SelectedIndexChanged);
            // 
            // lblTweight
            // 
            this.lblTweight.AutoSize = true;
            this.lblTweight.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblTweight.Location = new System.Drawing.Point(468, 237);
            this.lblTweight.Name = "lblTweight";
            this.lblTweight.Size = new System.Drawing.Size(110, 19);
            this.lblTweight.TabIndex = 4;
            this.lblTweight.Text = "Total Weight :";
            // 
            // lblTjobs
            // 
            this.lblTjobs.AutoSize = true;
            this.lblTjobs.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblTjobs.Location = new System.Drawing.Point(258, 237);
            this.lblTjobs.Name = "lblTjobs";
            this.lblTjobs.Size = new System.Drawing.Size(92, 19);
            this.lblTjobs.TabIndex = 4;
            this.lblTjobs.Text = "Total Jobs :";
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(800, 331);
            this.Controls.Add(this.lblTjobs);
            this.Controls.Add(this.lblTweight);
            this.Controls.Add(this.cmbFilteritem);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgvReports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Reports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reports";
            this.Load += new System.EventHandler(this.Reports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReports)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvReports;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ComboBox cmbFilteritem;
        private System.Windows.Forms.Label lblTweight;
        private System.Windows.Forms.Label lblTjobs;
    }
}