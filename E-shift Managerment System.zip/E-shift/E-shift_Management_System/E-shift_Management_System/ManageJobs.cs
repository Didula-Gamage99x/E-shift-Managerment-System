﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class ManageJobs : Form
    {
        public ManageJobs()
        {
            InitializeComponent();// Initialize UI components
            // Set up DataGridView columns with new order
            dgvMjobs.Columns.Clear();
            dgvMjobs.Columns.Add("JobID", "Job ID");
            dgvMjobs.Columns.Add("Customer", "Customer");
            dgvMjobs.Columns.Add("StartLocation", "Start Location");
            dgvMjobs.Columns.Add("EndLocation", "End Location");

            dgvMjobs.Columns.Add("VehicleType", "Vehicle Type");
            dgvMjobs.Columns.Add("ItemReference", "Item Reference");
            dgvMjobs.Columns.Add("Weight", "Weight (kg)");
            dgvMjobs.Columns.Add("Date", "Date");
            dgvMjobs.Columns.Add("Status", "Status");

            LoadJobs(); // Load jobs from database into grid
        }
        private void LoadJobs()
        {
            dgvMjobs.Rows.Clear();

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = @"SELECT j.job_id, j.customer, j.start_location, j.end_location, 
                               j.job_date, j.status, j.weight, j.vehicle_type, i.name as item_reference
                               FROM jobs j
                               LEFT JOIN items i ON j.item_id = i.id";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    dgvMjobs.Rows.Add(
                        reader["job_id"].ToString(),
                        reader["customer"].ToString(),
                        reader["start_location"].ToString(),
                        reader["end_location"].ToString(),
                        reader["vehicle_type"] != DBNull.Value ? reader["vehicle_type"].ToString() : "",
                        reader["item_reference"] != DBNull.Value ? reader["item_reference"].ToString() : "",
                        reader["weight"] != DBNull.Value ? reader["weight"].ToString() : "",
                        Convert.ToDateTime(reader["job_date"]).ToString("yyyy-MM-dd"),
                        reader["status"].ToString()
                    );
                }
            }
        }

        private void UpdateJobStatus(string newStatus)
        {
            if (dgvMjobs.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a job to update.");
                return;
            }

            string selectedJobID = dgvMjobs.SelectedRows[0].Cells["JobID"].Value.ToString();

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "UPDATE jobs SET status = @status WHERE job_id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@status", newStatus);
                cmd.Parameters.AddWithValue("@id", selectedJobID);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show($"Job {selectedJobID} updated to '{newStatus}'");
            LoadJobs();
        }
        private void ManageJobs_Load(object sender, EventArgs e)
        {

        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            UpdateJobStatus("Accepted");
        }

        private void btnDecline_Click(object sender, EventArgs e)
        {
            UpdateJobStatus("Declined");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close(); // Go back to Admin Dashboard
        }

        private void dgvMjobs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
