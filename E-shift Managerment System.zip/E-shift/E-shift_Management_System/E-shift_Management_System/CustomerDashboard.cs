﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class CustomerDashboard : Form
    {
        private string currentUsername;
        public CustomerDashboard(string username)
        {
            InitializeComponent();// Initialize UI components
            currentUsername = username;
            lblWelcome.Text = $"Welcome {username}";
        }

        private void CustomerDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnRjob_Click(object sender, EventArgs e)
        {
            RequestJob requestForm = new RequestJob(currentUsername);
            requestForm.ShowDialog();
        }

        private void btnMyjobs_Click(object sender, EventArgs e)
        {
            MyJobs myJobsForm = new MyJobs(currentUsername);
            myJobsForm.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.Show();
            this.Close();
        }
    }
}
