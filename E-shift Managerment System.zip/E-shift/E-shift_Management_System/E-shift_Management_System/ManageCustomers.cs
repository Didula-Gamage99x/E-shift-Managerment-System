﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class ManageCustomers : Form
    {
        public ManageCustomers()
        {
            InitializeComponent();// Initialize UI components
            LoadCustomers();// Load customer data when form starts
        }
        private void LoadCustomers()
        {
            dgvMcustomers.Rows.Clear();// Clear existing rows

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                // Query to get all customers (users with 'Customer' role)
                string query = "SELECT username, password, contact FROM users WHERE role = 'Customer'";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                // Add each customer to the DataGridView
                while (reader.Read())
                {
                    string username = reader["username"].ToString();
                    string password = reader["password"].ToString();
                    string contact = reader["contact"].ToString();
                    dgvMcustomers.Rows.Add(username, password, contact);
                }
            }
        }
        private void ManageCustomers_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close(); // Return to Admin Dashboard
        }

        private void btnAcustomer_Click(object sender, EventArgs e)
        {    
            // Get new customer details through input boxes
            string username = Microsoft.VisualBasic.Interaction.InputBox("Enter new customer's username:", "Add Customer");
            if (string.IsNullOrWhiteSpace(username)) return;// Exit if cancelled

            string password = Microsoft.VisualBasic.Interaction.InputBox("Enter password for new customer:", "Add Customer");
            if (string.IsNullOrWhiteSpace(password)) return;

            string contact = Microsoft.VisualBasic.Interaction.InputBox("Enter contact number for new customer:", "Add Customer");
            if (string.IsNullOrWhiteSpace(contact)) return;

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                // Check if username already exists
                string checkQuery = "SELECT COUNT(*) FROM users WHERE username = @user";
                SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                checkCmd.Parameters.AddWithValue("@user", username);

                int exists = (int)checkCmd.ExecuteScalar();
                if (exists > 0)
                {
                    MessageBox.Show("Username already exists.");
                    return;
                }

                // Insert new customer
                string insertQuery = "INSERT INTO users (username, password, contact, role) VALUES (@user, @pass, @contact, 'Customer')";
                SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
                insertCmd.Parameters.AddWithValue("@user", username);
                insertCmd.Parameters.AddWithValue("@pass", password);
                insertCmd.Parameters.AddWithValue("@contact", contact);
                insertCmd.ExecuteNonQuery();

                MessageBox.Show("Customer added successfully.");
                LoadCustomers();
            }
        }

        private void btnDcustomer_Click(object sender, EventArgs e)
        {  
            // Verify a customer is selected
            if (dgvMcustomers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a customer to delete.");
                return;
            }
            // Get username from selected row
            string username = dgvMcustomers.SelectedRows[0].Cells[0].Value.ToString();
            // Confirm deletion
            DialogResult result = MessageBox.Show($"Are you sure you want to delete customer '{username}'?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (result == DialogResult.No) return;

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string deleteQuery = "DELETE FROM users WHERE username = @user AND role = 'Customer'";
                SqlCommand deleteCmd = new SqlCommand(deleteQuery, conn);
                deleteCmd.Parameters.AddWithValue("@user", username);
                int rows = deleteCmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    MessageBox.Show("Customer deleted.");
                }
                else
                {
                    MessageBox.Show("Failed to delete customer.");
                }

                LoadCustomers();
            }
        }

        private void dgvMcustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
