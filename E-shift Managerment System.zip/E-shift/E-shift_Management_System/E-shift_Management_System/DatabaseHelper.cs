﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_shift_Management_System
{
    internal class DatabaseHelper
    {
        public static SqlConnection GetConnection()
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\E-shift\E-shift_Management_System\E-shift_Management_System\Eshift_DB.mdf;Integrated Security=True";
            return new SqlConnection(connectionString);
        }
    }
}
