﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using E_shift_Management_System;

namespace E_shift_Management_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();// Initialize UI components
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
        
        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm regForm = new RegisterForm();
            regForm.ShowDialog();// Opens the registration form as a dialog
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            // Validate if username or password is empty
            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter both Username and Password.");
                return;// Exit if validation fails
            }
            // Establish a database connection (using 'using' ensures proper disposal)
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();// Open the connection
                // SQL query to check user credentials and role
                string query = "SELECT role FROM users WHERE username = @user AND password = @pass";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", username);
                cmd.Parameters.AddWithValue("@pass", password);
                // Execute the query and read the result
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string role = reader["role"].ToString();
                    // Redirect to the appropriate dashboard based on role
                    if (role == "Admin")
                    {
                        new AdminDashboard(username).Show();// Open Admin Dashboard
                    }
                    else if (role == "Customer")
                    {
                        new CustomerDashboard(username).Show();// Open Customer Dashboard
                    }

                    this.Hide();// Hide the login form after successful login
                }
                else
                {
                    MessageBox.Show("Invalid username or password.");// Show error if credentials are invalid
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm regForm = new RegisterForm();
            regForm.ShowDialog();
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm regForm = new RegisterForm();
            regForm.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();// Terminate the application
        }
    }
}
