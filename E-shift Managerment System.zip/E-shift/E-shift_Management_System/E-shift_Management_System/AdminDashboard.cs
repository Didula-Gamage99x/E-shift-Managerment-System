﻿using E_shift_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace E_shift_Management_System
{
    public partial class AdminDashboard : Form
    {
        private string adminUsername;
        // Constructor: Initializes the dashboard with the logged in admin's username
        public AdminDashboard(string username)
        {
            InitializeComponent();// Initialize UI components
            adminUsername = username;
            lblWelcome.Text = $"Welcome {adminUsername}";// Stores the username of the logged in admin

        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnMcust_Click(object sender, EventArgs e)
        {
            ManageCustomers manageForm = new ManageCustomers();
            manageForm.ShowDialog();
        }

        private void btnMjobr_Click(object sender, EventArgs e)
        {
            ManageJobs jobsForm = new ManageJobs();
            jobsForm.ShowDialog();
        }


        private void btnVreports_Click(object sender, EventArgs e)
        {
            Reports reportsForm = new Reports();
            reportsForm.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.Show();
            this.Close(); // Will return to login form
        }

        private void btnMitems_Click(object sender, EventArgs e)
        {
            ManageItems manageItems = new ManageItems();
            manageItems.ShowDialog();
        }
    }
}
