﻿using E_shift_Management_System;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace E_shift_Management_System
{
   
    public partial class MyJobs : Form
    {
        private string currentCustomer;
        public MyJobs(string username)
        {
            InitializeComponent();// Initialize UI components
            currentCustomer = username;

          
            InitializeDataGridViewColumns();

            // Then load the data
            LoadMyJobs();
        }
        private void InitializeDataGridViewColumns()
        {
            // Clear existing columns
            dgvMyjobs.Columns.Clear();

      
            dgvMyjobs.Columns.Add("JobID", "Job ID");
            dgvMyjobs.Columns.Add("Start", "Start Location");
            dgvMyjobs.Columns.Add("End", "End Location");
            dgvMyjobs.Columns.Add("Vehicle", "Vehicle Type");
            dgvMyjobs.Columns.Add("Item", "Item Reference");
            dgvMyjobs.Columns.Add("Weight", "Weight (kg)");
            dgvMyjobs.Columns.Add("Date", "Date");
            dgvMyjobs.Columns.Add("Status", "Status");

            
            DataGridViewTextBoxColumn amountCol = new DataGridViewTextBoxColumn();
            amountCol.Name = "Amount";
            amountCol.HeaderText = "Amount (Rs)";
            dgvMyjobs.Columns.Add(amountCol);
        }

        private void LoadMyJobs()
        {
            // Clear existing rows
            dgvMyjobs.Rows.Clear();

            try
            {
                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    // Query to get jobs with item names for current customer
                    string query = @"SELECT j.job_id, j.start_location, j.end_location, 
                                   j.job_date, j.status, j.weight, j.vehicle_type, i.name as item_name
                                   FROM jobs j
                                   LEFT JOIN items i ON j.item_id = i.id
                                   WHERE j.customer = @customer
                                   ORDER BY j.job_date DESC";// Newest jobs first

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@customer", currentCustomer);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Add each job to the grid with null checks
                            dgvMyjobs.Rows.Add(
                                reader["job_id"].ToString(),
                                reader["start_location"].ToString(),
                                reader["end_location"].ToString(),
                                reader["vehicle_type"] != DBNull.Value ? reader["vehicle_type"].ToString() : "",
                                reader["item_name"] != DBNull.Value ? reader["item_name"].ToString() : "",
                                reader["weight"] != DBNull.Value ? reader["weight"].ToString() : "",
                                Convert.ToDateTime(reader["job_date"]).ToString("yyyy-MM-dd"),
                                reader["status"].ToString(),
                                CalculateAmount(reader["weight"] != DBNull.Value ?
                                    Convert.ToDecimal(reader["weight"]) : 0,
                                    reader["vehicle_type"] != DBNull.Value ?
                                    reader["vehicle_type"].ToString() : "")
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading jobs: {ex.Message}");
            }
        }
        private decimal CalculateAmount(decimal weight, string vehicleType)
        {
            // Round up to nearest 5kg increment
            decimal roundedWeight = Math.Ceiling(weight / 5) * 5;

            // Pricing structure
            switch (vehicleType)
            {
                case "Small Lorry": return 1000 + (roundedWeight * 10);
                case "Medium Lorry": return 1500 + (roundedWeight * 8);
                case "Large Lorry": return 2000 + (roundedWeight * 6);
                default: return 800 + (roundedWeight * 12);
            }
        }
        private void MyJobs_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); // Go back to Admin Dashboard
        }

        private void dgvMyjobs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
